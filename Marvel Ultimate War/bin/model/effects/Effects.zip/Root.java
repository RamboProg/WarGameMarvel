package model.effects;

public class Root extends Effect{
	public Root(String name, int duration , EffectType type) {
		super(name , duration, type);
		type = EffectType.DEBUFF;
		
	}

}
