package model.effects;

public class Silence extends Effect{
	public Silence(String name, int duration , EffectType type) {
		super(name , duration, type);
		type = EffectType.DEBUFF;
		
	}
}
